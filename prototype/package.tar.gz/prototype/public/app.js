// ==========================================================================
// BugGraph Terminal Workstation Prototype — Client-Side REPL & Engine
// ==========================================================================

const API_BASE = window.location.origin;

// Preset Stack Traces
const PRESETS = {
  typeerror: `TypeError: Cannot read properties of undefined (reading 'map')
    at UserList (src/components/UserList.jsx:42:18)
    at renderWithHooks (node_modules/react-dom/cjs/react-dom.development.js:14985:18)
    at mountIndeterminateComponent (node_modules/react-dom/cjs/react-dom.development.js:17811:13)
    at beginWork (node_modules/react-dom/cjs/react-dom.development.js:19049:16)`,

  sqli: `Database Error: syntax error at or near "DROP"
    Query: SELECT * FROM accounts WHERE username = 'admin' OR '1'='1' AND role = 'user'
    at Client._query (node_modules/pg/lib/client.js:527:17)
    at AuthService.authenticate (src/services/auth.js:89:22)
    at processTicksAndRejections (node:internal/process/task_queues:95:5)`,

  oom: `FATAL ERROR: Ineffective mark-compacts near heap limit Allocation failed - JavaScript heap out of memory
    1: 0xb09c30 node::Abort() [node]
    2: 0xa1b20b node::FatalError(char const*, char const*) [node]
    3: 0xcf82de v8::Utils::ReportOOMFailure(v8::internal::Isolate*, char const*, bool) [node]
    at processHugeBuffer (src/processors/stream.js:12:20)`,

  sensitive: `Error: Connection rejected with DB_URL=postgres://app_user:SuperSecretP@ssw0rd123@db.prod.internal:5432/core
    OpenAI Key detected in env: sk-abcdef1234567890abcdef1234567890
    AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
    at PostgresPool.connect (src/db/connection.js:33:11)`
};

// Available Shell Commands for Autocomplete & Help
const SHELL_COMMANDS = [
  { cmd: 'solve', desc: 'Full AI diagnosis, root cause, code patch & O(N) complexity' },
  { cmd: 'tree', desc: 'Graphic tree visual representation of error call stack & affected files' },
  { cmd: 'explain', desc: 'Plain-English technical translation of compiler/runtime error' },
  { cmd: 'fix', desc: 'Generate concrete unified git patch diff' },
  { cmd: 'debug', desc: 'Interactive multi-turn debugging chat in terminal console' },
  { cmd: 'pipe', desc: 'Simulate stream pipe ingestion from stdin buffer' },
  { cmd: 'model', desc: 'Manage offline LLM provider (Ollama / LM Studio / Backend)' },
  { cmd: 'status', desc: 'Inspect engine connectivity, ping latency & graph health' },
  { cmd: 'sanitize', desc: 'Toggle secret scrubbing shield or test redaction' },
  { cmd: 'temp', desc: 'Set LLM sampling temperature (e.g. temp 0.2)' },
  { cmd: 'clear', desc: 'Clear terminal screen (Shortcut: Ctrl+L)' },
  { cmd: 'help', desc: 'List all workstation terminal commands' }
];

// App State
let commandHistory = [];
let historyIndex = -1;
let activeProvider = 'ollama';
let activeModel = 'qwen2.5-coder:7b';
let activeTemperature = 0.2;
let activeMaxTokens = 2048;
let sanitizeEnabled = true;
let latestGeneratedDiff = '';
let isExecuting = false;

// DOM Elements
const streamEl = document.getElementById('terminalStream');
const inputEl = document.getElementById('terminalInput');
const executeBtn = document.getElementById('executeBtn');
const pasteTraceBtn = document.getElementById('pasteTraceBtn');
const multilineToggleBtn = document.getElementById('multilineToggleBtn');
const autocompleteEl = document.getElementById('autocompletePopover');
const crtToggleBtn = document.getElementById('crtToggleBtn');
const proDockToggleBtn = document.getElementById('proDockToggleBtn');
const proDockEl = document.getElementById('proDockPane');
const terminalPaneEl = document.getElementById('terminalPane');
const splitterEl = document.getElementById('tuiSplitter');

// Pro Dock Elements
const modelSelectEl = document.getElementById('modelSelect');
const scanModelsBtn = document.getElementById('scanModelsBtn');
const testConnectionBtn = document.getElementById('testConnectionBtn');
const connectionFeedbackEl = document.getElementById('connectionFeedback');
const tempSliderEl = document.getElementById('tempSlider');
const tempValueEl = document.getElementById('tempValue');
const tokenSliderEl = document.getElementById('tokenSlider');
const tokenValueEl = document.getElementById('tokenValue');
const sanitizerSwitchEl = document.getElementById('sanitizerSwitch');
const testSanitizeBtn = document.getElementById('testSanitizeBtn');
const rawPromptPreviewEl = document.getElementById('rawPromptPreview');
const promptInspectorCard = document.getElementById('promptInspectorCard');
const latestDiffBox = document.getElementById('latestDiffBox');
const copyDiffBtn = document.getElementById('copyDiffBtn');
const applyPatchBtn = document.getElementById('applyPatchBtn');

// Telemetry Elements
const telemetryLatency = document.getElementById('telemetryLatency');
const telemetryTokSpeed = document.getElementById('telemetryTokSpeed');
const telemetryTokens = document.getElementById('telemetryTokens');
const telemetryConfidence = document.getElementById('telemetryConfidence');
const headerModelLabel = document.getElementById('headerModelLabel');
const headerLatencyLabel = document.getElementById('headerLatencyLabel');
const statusLabel = document.getElementById('statusLabel');

// ==========================================================================
// 1. BOOT SEQUENCE & WELCOME BANNER
// ==========================================================================
function bootTerminal() {
  const bootBanner = `
<div class="stream-block">
  <pre style="color: var(--neon-green); font-weight: bold; line-height: 1.15; font-size: 11px;">
  ██████╗ ██╗   ██╗ ██████╗  ██████╗ ██████╗  █████╗ ██████╗ ██╗  ██╗
  ██╔══██╗██║   ██║██╔════╝ ██╔════╝ ██╔══██╗██╔══██╗██╔══██╗██║  ██║
  ██████╔╝██║   ██║██║  ███╗██║  ███╗██████╔╝███████║██████╔╝███████║
  ██╔══██╗██║   ██║██║   ██║██║   ██║██╔══██╗██╔══██║██╔═══╝ ██╔══██║
  ██████╔╝╚██████╔╝╚██████╔╝╚██████╔╝██║  ██║██║  ██║██║     ██║  ██║
  ╚═════╝  ╚═════╝  ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝
  </pre>
  <div class="ansi-box header-box">
    <div class="ansi-box-title">
      <span>⚡ BUGGRAPH LOCAL WORKSTATION HUD // TERMINAL PROTOTYPE</span>
      <div class="ansi-meta-tags">
        <span class="meta-badge lang">READY</span>
        <span class="meta-badge model">AI_CORE</span>
        <span class="meta-badge latency">v1.0.0-PROTOTYPE</span>
      </div>
    </div>
    <div class="detail-row">
      <div class="row-content" style="color: var(--text-dim); font-size: 12px;">
        Interactive terminal environment connected to AI debugging engine and Knowledge Graph.<br>
        Type <span style="color: var(--neon-green); font-weight: 600;">'solve'</span>, 
        <span style="color: var(--neon-cyan); font-weight: 600;">'explain'</span>, 
        <span style="color: var(--neon-amber); font-weight: 600;">'fix'</span>, or 
        <span style="color: var(--neon-purple); font-weight: 600;">'debug'</span> to start diagnosing. 
        Or select a quick trace preset above.
      </div>
    </div>
  </div>
</div>`;

  streamEl.innerHTML = bootBanner;
  scrollToBottom();
  checkInitialStatus();
}

function scrollToBottom() {
  streamEl.scrollTop = streamEl.scrollHeight;
}

// ==========================================================================
// 2. STATUS & MODEL DISCOVERY
// ==========================================================================
async function checkInitialStatus() {
  try {
    const res = await fetch(`${API_BASE}/api/status`);
    const data = await res.json();

    if (data.config) {
      activeProvider = data.config.provider || 'ollama';
      activeModel = data.config.model || 'qwen2.5-coder:7b';
      activeTemperature = data.config.temperature ?? 0.2;
      activeMaxTokens = data.config.maxTokens || 2048;
      sanitizeEnabled = Boolean(data.config.sanitizeEnabled);

      updateProviderUI(activeProvider);
      tempSliderEl.value = activeTemperature;
      tempValueEl.textContent = activeTemperature;
      tokenSliderEl.value = activeMaxTokens;
      tokenValueEl.textContent = activeMaxTokens;
      sanitizerSwitchEl.checked = sanitizeEnabled;
      updateHeaderLabels();
    }

    if (data.localModels?.ollama?.online) {
      connectionFeedbackEl.textContent = `Ollama detected: ${data.localModels.ollama.models.length} local models.`;
      connectionFeedbackEl.className = 'feedback-text online';
      populateModelDropdown(data.localModels.ollama.models);
    } else if (data.localModels?.lmstudio?.online) {
      connectionFeedbackEl.textContent = `LM Studio detected: ${data.localModels.lmstudio.models.length} models.`;
      connectionFeedbackEl.className = 'feedback-text online';
      populateModelDropdown(data.localModels.lmstudio.models);
    } else {
      connectionFeedbackEl.textContent = `Offline Heuristic Engine ready (zero latency).`;
      connectionFeedbackEl.className = 'feedback-text online';
    }
  } catch (err) {
    statusLabel.textContent = 'STANDALONE_LOCAL: READY';
    headerLatencyLabel.textContent = '1ms';
  }
}

function updateHeaderLabels() {
  headerModelLabel.textContent = `${activeProvider}:${activeModel}`;
  headerLatencyLabel.textContent = telemetryLatency.textContent;
}

function populateModelDropdown(models) {
  if (!models || models.length === 0) return;
  modelSelectEl.innerHTML = '';
  models.forEach(m => {
    const opt = document.createElement('option');
    opt.value = m.name;
    opt.textContent = `${m.name} ${m.size ? `(${m.size})` : ''}`;
    modelSelectEl.appendChild(opt);
  });
  if (models[0]) {
    activeModel = models[0].name;
    updateHeaderLabels();
  }
}

// ==========================================================================
// 3. COMMAND PARSER & REPL ENGINE
// ==========================================================================
async function handleUserSubmit() {
  const rawInput = inputEl.value.trim();
  if (!rawInput || isExecuting) return;

  // Add to history
  commandHistory.push(rawInput);
  historyIndex = commandHistory.length;

  // Clear input
  inputEl.value = '';
  inputEl.style.height = '52px';
  autocompleteEl.style.display = 'none';

  // Render User Entry in Stream
  appendUserEntry(rawInput);

  // Parse Command
  const parts = rawInput.split(/\s+/);
  const command = parts[0].toLowerCase();
  const rest = parts.slice(1).join(' ');

  // Built-in Shell Commands
  if (command === 'clear') {
    streamEl.innerHTML = '';
    return;
  }

  if (command === 'help') {
    renderHelpBlock();
    return;
  }

  if (command === 'status') {
    await renderStatusBlock();
    return;
  }

  if (command === 'temp') {
    const val = parseFloat(rest);
    if (!isNaN(val) && val >= 0 && val <= 1) {
      activeTemperature = val;
      tempSliderEl.value = val;
      tempValueEl.textContent = val;
      appendSystemMessage(`Sampling temperature set to ${val}`);
      saveConfig({ temperature: val });
    } else {
      appendSystemMessage(`Usage: temp <0.0 - 1.0> (current: ${activeTemperature})`, 'warn');
    }
    return;
  }

  if (command === 'sanitize') {
    if (rest === 'on') {
      sanitizeEnabled = true;
    } else if (rest === 'off') {
      sanitizeEnabled = false;
    } else {
      sanitizeEnabled = !sanitizeEnabled;
    }
    sanitizerSwitchEl.checked = sanitizeEnabled;
    appendSystemMessage(`Secret scrubbing shield is now: ${sanitizeEnabled ? 'ENABLED (API keys & Passwords scrubbed)' : 'DISABLED'}`);
    saveConfig({ sanitizeEnabled });
    return;
  }

  if (command === 'model') {
    if (rest === 'scan') {
      await scanModels();
    } else if (rest.startsWith('set ')) {
      activeModel = rest.substring(4).trim();
      appendSystemMessage(`Active target model set to: ${activeModel}`);
      updateHeaderLabels();
      saveConfig({ model: activeModel });
    } else {
      appendSystemMessage(`Current Provider: ${activeProvider}\nTarget Model: ${activeModel}\nUse 'model scan' to detect local models or 'model set <name>'.`);
    }
    return;
  }

  // AI Diagnostic Commands: solve, explain, fix, debug, pipe, tree
  let cmdType = 'solve';
  let tracePayload = rest;

  if (['solve', 'explain', 'fix', 'debug', 'pipe', 'tree'].includes(command)) {
    cmdType = command;
    tracePayload = rest;
  } else {
    // If user pasted a raw stack trace directly without a command prefix, default to 'solve'
    cmdType = 'solve';
    tracePayload = rawInput;
  }

  if (!tracePayload) {
    // Inject preset or prompt user
    tracePayload = PRESETS.typeerror;
    appendSystemMessage(`No stack trace provided. Automatically loading sample TypeError for analysis...`, 'info');
  }

  await executeAICommand(cmdType, tracePayload);
}

function appendUserEntry(text) {
  const block = document.createElement('div');
  block.className = 'stream-block';
  block.innerHTML = `
    <div class="stream-user-entry">
      <span class="p-symbol">❯</span>
      <span class="cmd-text">${escapeHtml(text)}</span>
    </div>
  `;
  streamEl.appendChild(block);
  scrollToBottom();
}

function appendSystemMessage(msg, type = 'info') {
  const block = document.createElement('div');
  block.className = 'stream-block';
  const color = type === 'warn' ? 'var(--neon-amber)' : (type === 'error' ? 'var(--neon-red)' : 'var(--neon-cyan)');
  block.innerHTML = `
    <div style="padding: 6px 12px; background: rgba(255,255,255,0.02); border-left: 2px solid ${color}; color: ${color}; font-size: 12px;">
      ${escapeHtml(msg).replace(/\n/g, '<br>')}
    </div>
  `;
  streamEl.appendChild(block);
  scrollToBottom();
}

// ==========================================================================
// 4. AI INFERENCE EXECUTION
// ==========================================================================
async function executeAICommand(command, trace) {
  isExecuting = true;
  executeBtn.classList.add('loading');
  executeBtn.innerHTML = `<span>⏳ DIAGNOSING...</span>`;

  // Temporary Pending Stream Block
  const pendingBlock = document.createElement('div');
  pendingBlock.className = 'stream-block';
  pendingBlock.innerHTML = `
    <div class="ansi-box">
      <div style="display: flex; align-items: center; gap: 8px; color: var(--neon-cyan);">
        <span class="led-blink"></span>
        <span>Running <strong>${command.toUpperCase()}</strong> via [${activeProvider}:${activeModel}]...</span>
      </div>
    </div>
  `;
  streamEl.appendChild(pendingBlock);
  scrollToBottom();

  const startTime = Date.now();

  try {
    const res = await fetch(`${API_BASE}/api/command`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        command,
        trace,
        provider: activeProvider,
        model: activeModel,
        temperature: activeTemperature,
        maxTokens: activeMaxTokens,
        sanitizeEnabled
      })
    });

    const data = await res.json();
    pendingBlock.remove();

    renderInferenceResult(command, data, trace);
  } catch (err) {
    pendingBlock.remove();
    appendSystemMessage(`Execution Error: ${err.message}. Please check local engine.`, 'error');
  } finally {
    isExecuting = false;
    executeBtn.classList.remove('loading');
    executeBtn.innerHTML = `<span class="icon">▶</span> RUN <kbd>Ctrl+↵</kbd>`;
  }
}

function renderInferenceResult(command, data, trace) {
  const block = document.createElement('div');
  block.className = 'stream-block';

  const latency = data.latencyMs || 92;
  const tokenCount = data.tokenCount || 280;
  const tokSpeed = data.tokPerSec || '45.0';
  const confidence = data.structured?.graphContext?.confidenceScore || '98.4%';

  // Update Telemetry
  telemetryLatency.textContent = `${latency} ms`;
  telemetryTokSpeed.textContent = `${tokSpeed} tok/s`;
  telemetryTokens.textContent = `${tokenCount} tok`;
  telemetryConfidence.textContent = confidence;
  headerLatencyLabel.textContent = `${latency}ms`;

  // Update Inspector
  rawPromptPreviewEl.textContent = `SYSTEM PROMPT:\nYou are BugGraph AI, an elite debugging workstation agent.\n\nCOMMAND: ${command.toUpperCase()}\nSANITIZED TRACE:\n${data.sanitized ? '(Secrets Scrubbed via Regex Shield)\n' : ''}${trace}`;

  const callTree = data.callTree || data.structured?.callTree;
  const treeHtml = renderGraphicTreeHtml(callTree);

  // If command is specifically 'tree', render tree graph as primary card
  if (command === 'tree') {
    let html = `
    <div class="ansi-box header-box">
      <div class="ansi-box-title">
        <span>✔ ERROR CALL GRAPH &amp; FILE IMPACT TREE</span>
        <div class="ansi-meta-tags">
          <span class="meta-badge lang">GRAPH</span>
          <span class="meta-badge model">${data.provider}</span>
          <span class="meta-badge latency">${latency}ms</span>
        </div>
      </div>
      <div class="detail-row">
        ${treeHtml}
      </div>
    </div>`;
    block.innerHTML = html;
    streamEl.appendChild(block);
    scrollToBottom();
    return;
  }

  // Structured Heuristic or LLM Response
  if (data.structured) {
    const st = data.structured;
    latestGeneratedDiff = st.diffPatch || '';

    // Update Pro Dock diff viewer
    updateLatestDiffUI(latestGeneratedDiff);

    let html = `
    <div class="ansi-box header-box">
      <div class="ansi-box-title">
        <span>✔ ${st.errorType || 'ERROR DIAGNOSIS COMPLETE'}</span>
        <div class="ansi-meta-tags">
          <span class="meta-badge lang">${st.language?.toUpperCase() || 'CODE'}</span>
          <span class="meta-badge model">${data.provider}</span>
          <span class="meta-badge latency">${latency}ms</span>
        </div>
      </div>

      <!-- Root Cause -->
      <div class="detail-row">
        <span class="row-title">🔍 ROOT CAUSE IDENTIFICATION</span>
        <div class="row-content">${escapeHtml(st.rootCause)}</div>
      </div>

      <!-- Graphic Call & Impact Tree -->
      ${treeHtml ? `
      <div class="detail-row">
        <span class="row-title">🌳 ERROR CALL GRAPH &amp; AFFECTED FILES</span>
        ${treeHtml}
      </div>` : ''}

      <!-- Technical Explanation -->
      <div class="detail-row">
        <span class="row-title">📖 TECHNICAL BREAKDOWN</span>
        <div class="row-content">${escapeHtml(st.explanation)}</div>
      </div>

      <!-- Code Patch Unified Diff -->
      ${st.diffPatch ? `
      <div class="detail-row">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span class="row-title">🛠️ UNIFIED GIT PATCH DIFF</span>
          <button class="dock-btn text-only" onclick="navigator.clipboard.writeText(\`${escapeHtml(st.diffPatch)}\`); alert('Copied patch diff!');">Copy Diff</button>
        </div>
        <div class="diff-container">
          ${formatDiffHtml(st.diffPatch)}
        </div>
      </div>` : ''}

      <!-- Complexity Analysis -->
      ${st.complexity ? `
      <div class="detail-row">
        <span class="row-title">⏱️ COMPLEXITY & PERFORMANCE EVALUATION</span>
        <div class="row-content" style="color: var(--neon-cyan);">
          Time: <strong>${st.complexity.time}</strong> | Space: <strong>${st.complexity.space}</strong> — ${escapeHtml(st.complexity.rationale)}
        </div>
      </div>` : ''}

      <!-- Graph Context -->
      ${st.graphContext ? `
      <div class="detail-row" style="background: rgba(0, 255, 136, 0.05); padding: 6px 8px; border-radius: var(--radius-sm);">
        <span class="row-title" style="color: var(--neon-green);">🌐 KNOWLEDGE GRAPH LEDGER MATCH</span>
        <div class="row-content" style="font-size: 11px; color: var(--text-dim);">
          Pattern: <strong>${st.graphContext.matchedPattern}</strong> | Historical Occurrences: <strong>${st.graphContext.historicalFixes}</strong> | Neo4j Node: <code>${st.graphContext.neo4jNodeId}</code>
        </div>
      </div>` : ''}
    </div>`;

    block.innerHTML = html;
  } else if (data.rawResponse) {
    // Raw Output from Ollama or LM Studio
    block.innerHTML = `
    <div class="ansi-box header-box">
      <div class="ansi-box-title">
        <span>✔ ${command.toUpperCase()} RESPONSE</span>
        <div class="ansi-meta-tags">
          <span class="meta-badge model">${data.model}</span>
          <span class="meta-badge latency">${latency}ms</span>
        </div>
      </div>
      <div class="detail-row">
        <pre style="white-space: pre-wrap; font-family: var(--font-mono); font-size: 12px; color: var(--text-main);">${escapeHtml(data.rawResponse)}</pre>
      </div>
    </div>`;
  }

  streamEl.appendChild(block);
  scrollToBottom();
}

function renderGraphicTreeHtml(callTree) {
  if (!callTree) return '';
  const frames = callTree.frames || [];
  const blast = callTree.blastRadius || {};

  let nodesHtml = '';
  // 1. Root Error Node
  nodesHtml += `
    <div class="tree-node-item root">
      <div class="node-pin">🔴</div>
      <div class="node-card">
        <div class="node-card-top">
          <span class="node-badge root">CRASH ROOT</span>
          <span style="font-size:10px; color:var(--text-muted);">TOP-LEVEL EXCEPTION</span>
        </div>
        <div class="node-file-line" style="color:var(--neon-red); font-size:13px;">${escapeHtml(callTree.errorTitle || 'Runtime Crash')}</div>
      </div>
    </div>
  `;

  // 2. Frames
  frames.forEach((f) => {
    const isCulprit = f.role === 'culprit';
    const itemClass = isCulprit ? 'culprit' : 'frame';
    const pin = isCulprit ? '🎯' : '↳';
    const badgeClass = isCulprit ? 'culprit' : 'frame';
    const badgeText = isCulprit ? `CULPRIT #1 (${f.isUserCode ? 'APP CODE' : 'EXT'})` : (f.isUserCode ? 'APP CALLER' : 'FRAMEWORK HOOK');

    nodesHtml += `
      <div class="tree-node-item ${itemClass}">
        <div class="node-pin">${pin}</div>
        <div class="node-card">
          <div class="node-card-top">
            <span class="node-badge ${badgeClass}">${badgeText}</span>
            <span class="node-func-name">${escapeHtml(f.fn)}()</span>
          </div>
          <div class="node-file-line">
            ${escapeHtml(f.file)} <span style="color:var(--neon-cyan);">:${f.line}${f.col ? ':' + f.col : ''}</span>
          </div>
          ${f.snippet ? `<div class="node-code-snippet">⚡ ${escapeHtml(f.snippet)}</div>` : ''}
        </div>
      </div>
    `;
  });

  // 3. Blast Radius
  nodesHtml += `
    <div class="tree-node-item blast">
      <div class="node-pin">💥</div>
      <div class="node-card">
        <div class="node-card-top">
          <span class="node-badge blast">BLAST RADIUS</span>
          <span style="font-size:10px; color:var(--neon-purple); font-weight:700;">SEVERITY: ${escapeHtml(blast.severity || 'HIGH')}</span>
        </div>
        <div class="node-file-line" style="color:var(--text-main); font-size:11px;">
          ${escapeHtml(blast.impact || 'Execution interrupted.')}
        </div>
        <div style="font-size:10px; color:var(--text-muted); margin-top:2px;">
          Impacted Boundary: <strong style="color:var(--text-dim);">${escapeHtml(blast.scope || 'Application Pipeline')}</strong>
        </div>
      </div>
    </div>
  `;

  return `
    <div class="tree-graph-container">
      <div class="tree-graph-header">
        <div class="tree-title-group">
          <span>🌳</span>
          <span class="tree-title">ERROR CALL GRAPH &amp; FILE IMPACT TREE</span>
        </div>
        <div class="tree-view-toggle">
          <button class="tree-toggle-btn active" onclick="toggleTreeView(this, 'graphic')">Node Tree</button>
          <button class="tree-toggle-btn" onclick="toggleTreeView(this, 'ascii')">ASCII</button>
        </div>
      </div>

      <!-- Graphic Flow -->
      <div class="tree-nodes-flow">
        ${nodesHtml}
      </div>

      <!-- Plain Text ASCII Tree -->
      <pre class="tree-ascii-pre">${escapeHtml(callTree.asciiTree || '')}</pre>
    </div>
  `;
}

window.toggleTreeView = function(btn, mode) {
  const container = btn.closest('.tree-graph-container');
  if (!container) return;
  const buttons = container.querySelectorAll('.tree-toggle-btn');
  buttons.forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  if (mode === 'ascii') {
    container.classList.add('show-ascii');
  } else {
    container.classList.remove('show-ascii');
  }
};

function formatDiffHtml(diffText) {
  const lines = diffText.split('\n');
  return lines.map(line => {
    if (line.startsWith('+')) {
      return `<span class="diff-line add">${escapeHtml(line)}</span>`;
    } else if (line.startsWith('-')) {
      return `<span class="diff-line del">${escapeHtml(line)}</span>`;
    } else if (line.startsWith('@@')) {
      return `<span class="diff-line hunk">${escapeHtml(line)}</span>`;
    } else {
      return `<span class="diff-line">${escapeHtml(line)}</span>`;
    }
  }).join('');
}

function updateLatestDiffUI(diffText) {
  if (!diffText) return;
  latestDiffBox.innerHTML = `<div class="diff-container" style="border:none; padding: 2px;">${formatDiffHtml(diffText)}</div>`;
  copyDiffBtn.disabled = false;
  applyPatchBtn.disabled = false;
}

// ==========================================================================
// 5. HELPER RENDERS (HELP, STATUS)
// ==========================================================================
function renderHelpBlock() {
  const rows = SHELL_COMMANDS.map(c => 
    `<tr>
      <td style="color: var(--neon-green); font-weight: 600; padding: 3px 12px 3px 0;">${c.cmd}</td>
      <td style="color: var(--text-dim); font-size: 12px;">${c.desc}</td>
    </tr>`
  ).join('');

  const block = document.createElement('div');
  block.className = 'stream-block';
  block.innerHTML = `
    <div class="ansi-box">
      <div class="ansi-box-title">
        <span>📖 AVAILABLE TERMINAL COMMANDS</span>
      </div>
      <table style="width: 100%; border-collapse: collapse;">
        ${rows}
      </table>
      <div style="font-size: 11px; color: var(--text-muted); margin-top: 8px;">
        💡 Tip: You can paste any raw stack trace directly and press <kbd>Ctrl+Enter</kbd> to solve.
      </div>
    </div>
  `;
  streamEl.appendChild(block);
  scrollToBottom();
}

async function renderStatusBlock() {
  const block = document.createElement('div');
  block.className = 'stream-block';
  block.innerHTML = `
    <div class="ansi-box">
      <div class="ansi-box-title">
        <span>⚙️ SYSTEM & ENGINE HEALTH STATUS</span>
      </div>
      <div style="display: grid; grid-template-columns: 140px 1fr; gap: 6px; font-size: 12px;">
        <span style="color: var(--text-muted);">Active Provider:</span>
        <span style="color: var(--neon-cyan); font-weight: 600;">${activeProvider.toUpperCase()}</span>

        <span style="color: var(--text-muted);">Target Model:</span>
        <span style="color: var(--neon-green);">${activeModel}</span>

        <span style="color: var(--text-muted);">Secret Sanitizer:</span>
        <span style="color: ${sanitizeEnabled ? 'var(--neon-green)' : 'var(--neon-red)'}; font-weight: 600;">
          ${sanitizeEnabled ? 'ENABLED (Shield Active)' : 'DISABLED'}
        </span>

        <span style="color: var(--text-muted);">Temperature:</span>
        <span>${activeTemperature}</span>

        <span style="color: var(--text-muted);">Max Tokens:</span>
        <span>${activeMaxTokens}</span>

        <span style="color: var(--text-muted);">Workstation Host:</span>
        <span style="color: var(--text-dim);">${window.location.host}</span>
      </div>
    </div>
  `;
  streamEl.appendChild(block);
  scrollToBottom();
}

// ==========================================================================
// 6. EVENT LISTENERS & PRO DOCK CONTROLS
// ==========================================================================
function setupEventListeners() {
  // Input Keydown Handling (Ctrl+Enter, History, Autocomplete)
  inputEl.addEventListener('keydown', (e) => {
    // Ctrl+Enter or Cmd+Enter to execute
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleUserSubmit();
      return;
    }

    // Single Enter when not multiline
    if (e.key === 'Enter' && !e.shiftKey && inputEl.rows === 1) {
      e.preventDefault();
      handleUserSubmit();
      return;
    }

    // Ctrl+L to Clear
    if (e.key === 'l' && e.ctrlKey) {
      e.preventDefault();
      streamEl.innerHTML = '';
      return;
    }

    // History traversal on single line
    if (inputEl.rows === 1) {
      if (e.key === 'ArrowUp') {
        if (historyIndex > 0) {
          historyIndex--;
          inputEl.value = commandHistory[historyIndex] || '';
        }
      } else if (e.key === 'ArrowDown') {
        if (historyIndex < commandHistory.length - 1) {
          historyIndex++;
          inputEl.value = commandHistory[historyIndex] || '';
        } else {
          historyIndex = commandHistory.length;
          inputEl.value = '';
        }
      }
    }
  });

  // Autocomplete & Auto-resize on typing
  inputEl.addEventListener('input', () => {
    // Dynamic comfortable height expansion
    inputEl.style.height = 'auto';
    const nextHeight = Math.min(Math.max(inputEl.scrollHeight, 52), 220);
    inputEl.style.height = `${nextHeight}px`;

    const val = inputEl.value.trim().toLowerCase();
    if (!val || val.includes(' ') || val.includes('\n')) {
      autocompleteEl.style.display = 'none';
      return;
    }

    const matches = SHELL_COMMANDS.filter(c => c.cmd.startsWith(val));
    if (matches.length > 0) {
      autocompleteEl.innerHTML = matches.map(m => `
        <div class="autocomplete-item" data-cmd="${m.cmd}">
          <span style="color: var(--neon-green); font-weight:600;">${m.cmd}</span>
          <span class="autocomplete-desc">${m.desc}</span>
        </div>
      `).join('');
      autocompleteEl.style.display = 'block';
    } else {
      autocompleteEl.style.display = 'none';
    }
  });

  // Click autocomplete item
  autocompleteEl.addEventListener('click', (e) => {
    const item = e.target.closest('.autocomplete-item');
    if (item) {
      inputEl.value = item.getAttribute('data-cmd') + ' ';
      autocompleteEl.style.display = 'none';
      inputEl.focus();
    }
  });

  // Execute Button Click
  executeBtn.addEventListener('click', handleUserSubmit);

  // Quick Action Buttons
  document.querySelectorAll('.fn-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const cmd = btn.getAttribute('data-cmd');
      if (cmd === 'clear') {
        streamEl.innerHTML = '';
      } else {
        inputEl.value = `${cmd} `;
        inputEl.focus();
      }
    });
  });

  // Trace Presets Click
  document.querySelectorAll('.preset-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const presetKey = chip.getAttribute('data-preset');
      const trace = PRESETS[presetKey];
      if (trace) {
        inputEl.value = `solve\n${trace}`;
        inputEl.rows = 4;
        inputEl.focus();
      }
    });
  });

  // Multiline Toggle
  multilineToggleBtn.addEventListener('click', () => {
    if (inputEl.rows === 1 || inputEl.clientHeight < 80) {
      inputEl.rows = 6;
      inputEl.style.height = '140px';
    } else {
      inputEl.rows = 1;
      inputEl.style.height = '52px';
    }
    inputEl.focus();
  });

  // Paste Trace Button
  pasteTraceBtn.addEventListener('click', async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        inputEl.value = text;
        inputEl.rows = 4;
        inputEl.focus();
      }
    } catch {
      inputEl.focus();
    }
  });

  // CRT Scanlines Toggle
  crtToggleBtn.addEventListener('click', () => {
    const isEnabled = document.body.classList.toggle('crt-enabled');
    crtToggleBtn.innerHTML = `<span class="icon">📺</span> CRT: ${isEnabled ? 'ON' : 'OFF'}`;
  });

  // Pro Dock Toggle
  proDockToggleBtn.addEventListener('click', () => {
    proDockEl.classList.toggle('collapsed');
  });

  // Drag & Drop File onto Terminal Pane
  terminalPaneEl.addEventListener('dragover', (e) => {
    e.preventDefault();
    terminalPaneEl.classList.add('drag-over');
  });

  terminalPaneEl.addEventListener('dragleave', () => {
    terminalPaneEl.classList.remove('drag-over');
  });

  terminalPaneEl.addEventListener('drop', async (e) => {
    e.preventDefault();
    terminalPaneEl.classList.remove('drag-over');
    if (e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      const text = await file.text();
      inputEl.value = `solve\n${text}`;
      inputEl.rows = 6;
      inputEl.focus();
      appendSystemMessage(`Buffered file '${file.name}' (${(file.size / 1024).toFixed(1)} KB) into input. Press Ctrl+Enter to solve.`);
    }
  });

  // Provider Radio Switch
  document.querySelectorAll('.provider-radio').forEach(label => {
    label.addEventListener('click', () => {
      document.querySelectorAll('.provider-radio').forEach(l => l.classList.remove('active'));
      label.classList.add('active');
      const provider = label.getAttribute('data-provider');
      updateProviderUI(provider);
      saveConfig({ provider });
    });
  });

  // Temperature Slider
  tempSliderEl.addEventListener('input', (e) => {
    activeTemperature = parseFloat(e.target.value);
    tempValueEl.textContent = activeTemperature;
  });
  tempSliderEl.addEventListener('change', () => {
    saveConfig({ temperature: activeTemperature });
  });

  // Max Tokens Slider
  tokenSliderEl.addEventListener('input', (e) => {
    activeMaxTokens = parseInt(e.target.value, 10);
    tokenValueEl.textContent = activeMaxTokens;
  });
  tokenSliderEl.addEventListener('change', () => {
    saveConfig({ maxTokens: activeMaxTokens });
  });

  // Sanitizer Switch
  sanitizerSwitchEl.addEventListener('change', (e) => {
    sanitizeEnabled = e.target.checked;
    saveConfig({ sanitizeEnabled });
  });

  // Test Sanitizer
  testSanitizeBtn.addEventListener('click', async () => {
    const sample = PRESETS.sensitive;
    const res = await fetch(`${API_BASE}/api/sanitize`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: sample })
    });
    const data = await res.json();
    appendSystemMessage(`SANITIZER REDACTION TEST:\nOriginal DB String contains password & AWS key.\nScrubbed Output:\n${data.sanitized}`, 'info');
  });

  // Scan Models Button
  scanModelsBtn.addEventListener('click', scanModels);

  // Test Connection Button
  testConnectionBtn.addEventListener('click', testConnection);

  // Model Selection Change
  modelSelectEl.addEventListener('change', (e) => {
    activeModel = e.target.value;
    updateHeaderLabels();
    saveConfig({ model: activeModel });
  });

  // Copy Diff Button
  copyDiffBtn.addEventListener('click', () => {
    if (latestGeneratedDiff) {
      navigator.clipboard.writeText(latestGeneratedDiff);
      alert('Unified git diff copied to clipboard!');
    }
  });

  // Collapsible Inspector Toggle
  document.getElementById('toggleInspectorHeader').addEventListener('click', () => {
    promptInspectorCard.classList.toggle('collapsed');
  });

  // Resizable Splitter
  let isResizing = false;
  splitterEl.addEventListener('mousedown', () => {
    isResizing = true;
    document.body.style.cursor = 'col-resize';
  });

  window.addEventListener('mousemove', (e) => {
    if (!isResizing) return;
    const containerWidth = document.querySelector('.tui-workspace').clientWidth;
    const newDockWidth = containerWidth - e.clientX;
    if (newDockWidth >= 280 && newDockWidth <= 600) {
      proDockEl.style.width = `${newDockWidth}px`;
    }
  });

  window.addEventListener('mouseup', () => {
    if (isResizing) {
      isResizing = false;
      document.body.style.cursor = 'default';
    }
  });
}

function updateProviderUI(provider) {
  activeProvider = provider;
  updateHeaderLabels();
  testConnection();
}

async function scanModels() {
  scanModelsBtn.innerHTML = `<span>⏳ Scanning...</span>`;
  try {
    const res = await fetch(`${API_BASE}/api/llm/models`);
    const data = await res.json();
    if (activeProvider === 'ollama' && data.ollama?.online) {
      populateModelDropdown(data.ollama.models);
      connectionFeedbackEl.textContent = `Scanned: ${data.ollama.models.length} Ollama models found.`;
      connectionFeedbackEl.className = 'feedback-text online';
    } else if (activeProvider === 'lmstudio' && data.lmstudio?.online) {
      populateModelDropdown(data.lmstudio.models);
      connectionFeedbackEl.textContent = `Scanned: ${data.lmstudio.models.length} LM Studio models.`;
      connectionFeedbackEl.className = 'feedback-text online';
    } else {
      connectionFeedbackEl.textContent = `Provider offline. Using Heuristic AI engine.`;
      connectionFeedbackEl.className = 'feedback-text online';
    }
  } catch (err) {
    connectionFeedbackEl.textContent = `Scan failed: ${err.message}`;
  } finally {
    scanModelsBtn.innerHTML = `<span>🔄 Scan</span>`;
  }
}

async function testConnection() {
  connectionFeedbackEl.textContent = 'Pinging target...';
  connectionFeedbackEl.className = 'feedback-text checking';
  try {
    const res = await fetch(`${API_BASE}/api/llm/test`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ provider: activeProvider })
    });
    const data = await res.json();
    connectionFeedbackEl.textContent = data.details || 'Connection verified';
    connectionFeedbackEl.className = data.success ? 'feedback-text online' : 'feedback-text offline';
  } catch {
    connectionFeedbackEl.textContent = 'Target offline. Heuristic fallback active.';
    connectionFeedbackEl.className = 'feedback-text online';
  }
}

async function saveConfig(updates) {
  try {
    await fetch(`${API_BASE}/api/config`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
  } catch {
    // Local memory only
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// Boot on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  bootTerminal();
  setupEventListeners();
});
