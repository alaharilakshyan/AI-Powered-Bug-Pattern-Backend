# BugGraph Prototype: Terminal Workstation HUD

> **Testing Sandbox**: Dedicated prototype directory evaluating the terminal aesthetic, local offline LLM dispatcher, and developer pro options before integrating into the main codebase.

---

## 🚀 How to Run the Prototype

You can launch the prototype workstation in either of two ways:

```bash
# Option 1: Via npm script
npm run prototype

# Option 2: Directly via node
node prototype/run.js
```

This starts the prototype server at `http://127.0.0.1:4568` and automatically opens a **dedicated standalone application window** (`1260x840`) with the Cyberpunk Terminal HUD!

---

## 🧠 Offline LLM Integration

The prototype includes an intelligent local model gateway in `prototype/server.js`:

1. **Local Ollama (`http://127.0.0.1:11434`)**:
   - If Ollama is running on your system, click **`[ 🔄 Scan ]`** in the Pro Dock.
   - It will automatically discover your installed models (e.g. `qwen2.5-coder:7b`, `deepseek-coder:6.7b`, `llama3.2`, etc.).
   - Commands like `solve`, `explain`, `fix`, and `debug` will prompt your local Ollama daemon directly.

2. **LM Studio / vLLM / LocalAI (`http://127.0.0.1:1234/v1`)**:
   - Select the **LM Studio / vLLM** radio button in the Pro Dock.
   - Uses standard OpenAI-compatible endpoints with local inference.

3. **Central Backend (`http://127.0.0.1:3000`)**:
   - Routes requests to the central BugGraph API and Neo4j knowledge graph.

4. **Zero-Latency Offline Heuristic Engine**:
   - If no LLM daemon is running, the workstation never crashes or hangs!
   - It instantly falls back to the built-in heuristic diagnosis engine with root cause analysis, unified git patch diffs, and $O(N)$ complexity evaluation.

---

## ⌨️ Terminal Commands

Inside the workstation terminal prompt (`❯`), you can type:

* **`solve`**: Comprehensive analysis of error, root cause, code patch, and complexity.
* **`tree`**: Graphic tree visual representation of error call stack & affected files.
* **`explain`**: Translates compiler errors into plain technical terms.
* **`fix`**: Generates a unified git patch diff.
* **`debug`**: Interactive multi-turn debugging chat.
* **`model`**: Inspects or hot-swaps active LLM provider (`model scan`, `model set <name>`).
* **`status`**: Checks engine health, ping latency, and model status.
* **`sanitize [on|off]`**: Toggles regex secret scrubbing (API keys, passwords, DB URIs).
* **`temp <0.0 - 1.0>`**: Changes LLM sampling temperature.
* **`clear`** or **`Ctrl+L`**: Clears terminal output stream.
* **`help`**: Displays command reference table.

> 💡 **Quick Tip**: You can also click the top quick function buttons (`[ > solve ]`, `[ > fix ]`, `[ > explain ]`) or select a preset chip (`TypeError`, `SQL Injection`, `Heap OOM`).

---

## 🛠️ Developer Pro Dock ("For the Pros")

On the right side of the screen, the Pro Dock provides deep runtime controls:
* **LLM Provider Selector**: Hot-swap between Ollama, LM Studio, Central Backend, and Heuristic AI.
* **Inference Dials**: Live sliders for Temperature ($0.0$ to $1.0$) and Max Output Tokens ($256$ to $4096$).
* **Real-Time Telemetry**: Latency (ms), Tokens Generated, Speed (tok/s), and Confidence score.
* **Secret Sanitizer Shield**: Toggles automated redaction of sensitive credentials before LLM processing.
* **Raw Prompt & KG Context Inspector**: Expandable drawer showing the exact prompt injected into the model.
* **Diff Fast-Box**: Live view of generated git patches with one-click copy and apply.
* **Draggable Splitter**: Drag the center divider to resize the terminal and dock panes.
* **CRT Scanline Filter**: Toggle the retro hacker CRT scanline glow on or off anytime.
